Margin Percentage functionality in Quotation or Sales Order
-----------------------------------------------------------

At what margin, you are doing business is one of of the key important indicator of the success to your business. Setting this key indicator in the ERP will be one of the key measure for your sales activity.

The term sales margin refers to an operating performance measure that allows key stakeholder  to understand the profitability of individual revenue-generating activities from your quotation and sales order.

It's very important to have the margin percentage on the Quotation and Sales Order itself in Odoo to get the idea about how profitable the order is. This margin percentage will be calculated and displayed on each of the produce and on allover total margin on the Quotation and Sales Order.

An effort towards providing decision making information through the product’s cost and sales price in Odoo, we develop the following module that will be very helpful to getting the margin percentage value in the Quotation and Sales Order.

This module will give the margin percentage on the Order Line of product from its purchase cost and sales price. And it will also provide the overall margin of the particular Quotation or Sales Order.
