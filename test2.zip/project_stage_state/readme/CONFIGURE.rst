You can configure stages from Project -> Configuration -> Stages
