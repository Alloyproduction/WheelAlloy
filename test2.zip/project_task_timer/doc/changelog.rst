Changelog
=========
* Jesni Banu        contact: jesni@cybrosys.in

`10.0.2.0.0`
------------
- Timer unit changed to minutes (To compact time sheet).

`10.0.3.0.0`
------------
- Windows Platform Issue: Xpath Changed in XML view.